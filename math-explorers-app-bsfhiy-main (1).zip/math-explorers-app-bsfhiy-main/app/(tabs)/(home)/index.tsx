
import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Platform } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useProgress } from '@/contexts/ProgressContext';

interface MathTopic {
  id: string;
  title: string;
  icon: string;
  color: string;
  route: string;
  description: string;
}

const mathTopics: MathTopic[] = [
  {
    id: 'addition',
    title: 'Addition',
    icon: '➕',
    color: '#A2D2FF',
    route: '/additionGame',
    description: 'Learn to add numbers together!',
  },
  {
    id: 'subtraction',
    title: 'Subtraction',
    icon: '➖',
    color: '#F2BAC9',
    route: '/subtractionGame',
    description: 'Practice taking numbers away!',
  },
  {
    id: 'multiplication',
    title: 'Multiplication',
    icon: '✖️',
    color: '#9A89B8',
    route: '/multiplicationGame',
    description: 'Master times tables!',
  },
  {
    id: 'division',
    title: 'Division',
    icon: '➗',
    color: '#E9D5DA',
    route: '/divisionGame',
    description: 'Learn to share equally!',
  },
];

export default function HomeScreen() {
  const router = useRouter();
  const { totalScore, gameProgress } = useProgress();

  const handleTopicPress = (route: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push(route as any);
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Math Adventures',
          headerStyle: {
            backgroundColor: colors.background,
          },
          headerTintColor: colors.text,
          headerTitleStyle: {
            fontFamily: 'Nunito_800ExtraBold',
            fontSize: 24,
          },
        }}
      />
      <View style={styles.container}>
        <ScrollView
          contentContainerStyle={[
            styles.scrollContent,
            Platform.OS !== 'ios' && styles.scrollContentWithTabBar,
          ]}
          showsVerticalScrollIndicator={false}
        >
          <Animated.View entering={FadeInDown.delay(100)} style={styles.header}>
            <Text style={styles.welcomeText}>Welcome to Math Adventures! 🎉</Text>
            <View style={styles.scoreCard}>
              <Text style={styles.scoreLabel}>Total Score</Text>
              <Text style={styles.scoreValue}>{totalScore}</Text>
            </View>
          </Animated.View>

          <View style={styles.topicsContainer}>
            {mathTopics.map((topic, index) => (
              <Animated.View
                key={topic.id}
                entering={FadeInDown.delay(200 + index * 100)}
              >
                <Pressable
                  style={({ pressed }) => [
                    styles.topicCard,
                    { backgroundColor: topic.color },
                    pressed && styles.topicCardPressed,
                  ]}
                  onPress={() => handleTopicPress(topic.route)}
                >
                  <View style={styles.topicIconContainer}>
                    <Text style={styles.topicIcon}>{topic.icon}</Text>
                  </View>
                  <View style={styles.topicContent}>
                    <Text style={styles.topicTitle}>{topic.title}</Text>
                    <Text style={styles.topicDescription}>{topic.description}</Text>
                    <View style={styles.progressBar}>
                      <View
                        style={[
                          styles.progressFill,
                          {
                            width: `${Math.min(
                              (gameProgress[topic.id as keyof typeof gameProgress] / 100) * 100,
                              100
                            )}%`,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>
                      {gameProgress[topic.id as keyof typeof gameProgress]} points
                    </Text>
                  </View>
                  <IconSymbol name="chevron.right" size={24} color={colors.text} />
                </Pressable>
              </Animated.View>
            ))}
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  scrollContentWithTabBar: {
    paddingBottom: 120,
  },
  header: {
    marginBottom: 24,
  },
  welcomeText: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 16,
    fontFamily: 'Nunito_800ExtraBold',
  },
  scoreCard: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  scoreLabel: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 8,
    fontFamily: 'Nunito_600SemiBold',
  },
  scoreValue: {
    fontSize: 48,
    fontWeight: '800',
    color: colors.primary,
    fontFamily: 'Nunito_800ExtraBold',
  },
  topicsContainer: {
    gap: 16,
  },
  topicCard: {
    borderRadius: 20,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.3)',
    elevation: 5,
  },
  topicCardPressed: {
    opacity: 0.8,
    transform: [{ scale: 0.98 }],
  },
  topicIconContainer: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  topicIcon: {
    fontSize: 40,
  },
  topicContent: {
    flex: 1,
  },
  topicTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 4,
    fontFamily: 'Nunito_800ExtraBold',
  },
  topicDescription: {
    fontSize: 14,
    color: colors.text,
    marginBottom: 8,
    fontFamily: 'Nunito_600SemiBold',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 4,
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.card,
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: colors.text,
    fontFamily: 'Nunito_600SemiBold',
  },
});


import React from 'react';
import { View, Text, StyleSheet, ScrollView, Platform, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '@/styles/commonStyles';
import Badge from '@/components/Badge';
import { useProgress } from '@/contexts/ProgressContext';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';

export default function ProfileScreen() {
  const { badges, totalScore, gameProgress, resetProgress } = useProgress();
  const earnedBadges = badges.filter((b) => b.earned);

  const handleReset = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    resetProgress();
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.contentContainer,
          Platform.OS !== 'ios' && styles.contentContainerWithTabBar,
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInDown.delay(100)} style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <Text style={styles.avatar}>🎓</Text>
          </View>
          <Text style={styles.name}>Math Champion</Text>
          <Text style={styles.subtitle}>Keep learning and growing!</Text>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(200)} style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{totalScore}</Text>
            <Text style={styles.statLabel}>Total Points</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{earnedBadges.length}</Text>
            <Text style={styles.statLabel}>Badges Earned</Text>
          </View>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(300)} style={styles.section}>
          <Text style={styles.sectionTitle}>Game Progress</Text>
          <View style={styles.progressGrid}>
            <View style={styles.progressItem}>
              <Text style={styles.progressIcon}>➕</Text>
              <Text style={styles.progressLabel}>Addition</Text>
              <Text style={styles.progressValue}>{gameProgress.addition}</Text>
            </View>
            <View style={styles.progressItem}>
              <Text style={styles.progressIcon}>➖</Text>
              <Text style={styles.progressLabel}>Subtraction</Text>
              <Text style={styles.progressValue}>{gameProgress.subtraction}</Text>
            </View>
            <View style={styles.progressItem}>
              <Text style={styles.progressIcon}>✖️</Text>
              <Text style={styles.progressLabel}>Multiplication</Text>
              <Text style={styles.progressValue}>{gameProgress.multiplication}</Text>
            </View>
            <View style={styles.progressItem}>
              <Text style={styles.progressIcon}>➗</Text>
              <Text style={styles.progressLabel}>Division</Text>
              <Text style={styles.progressValue}>{gameProgress.division}</Text>
            </View>
          </View>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(400)} style={styles.section}>
          <Text style={styles.sectionTitle}>
            Badges ({earnedBadges.length}/{badges.length})
          </Text>
          {badges.map((badge, index) => (
            <Animated.View key={badge.id} entering={FadeInDown.delay(500 + index * 50)}>
              <Badge
                icon={badge.icon}
                name={badge.name}
                description={badge.description}
                earned={badge.earned}
                earnedDate={badge.earnedDate}
              />
            </Animated.View>
          ))}
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(900)} style={styles.aboutSection}>
          <Text style={styles.sectionTitle}>About</Text>
          <View style={styles.aboutCard}>
            <Text style={styles.aboutIcon}>👥</Text>
            <Text style={styles.aboutLabel}>Created by</Text>
            <Text style={styles.ownerName}>Phindile Nozipho Sithole</Text>
            <Text style={styles.ownerName}>Mthokozisi Goodman Dlamini</Text>
            <Text style={styles.aboutDescription}>
              An educational app designed to help kids learn basic math through fun and engaging mini-games.
            </Text>
            <Text style={styles.versionText}>Version 1.0.0</Text>
          </View>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(1000)}>
          <Pressable
            style={({ pressed }) => [
              styles.resetButton,
              pressed && styles.resetButtonPressed,
            ]}
            onPress={handleReset}
          >
            <Text style={styles.resetButtonText}>Reset Progress</Text>
          </Pressable>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  contentContainerWithTabBar: {
    paddingBottom: 120,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 24,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  avatar: {
    fontSize: 60,
  },
  name: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 4,
    fontFamily: 'Nunito_800ExtraBold',
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    fontFamily: 'Nunito_600SemiBold',
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  statValue: {
    fontSize: 36,
    fontWeight: '800',
    color: colors.primary,
    marginBottom: 4,
    fontFamily: 'Nunito_800ExtraBold',
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    fontFamily: 'Nunito_600SemiBold',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 16,
    fontFamily: 'Nunito_800ExtraBold',
  },
  progressGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  progressItem: {
    width: '48%',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  progressIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  progressLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 4,
    fontFamily: 'Nunito_600SemiBold',
  },
  progressValue: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.primary,
    fontFamily: 'Nunito_800ExtraBold',
  },
  aboutSection: {
    marginBottom: 24,
  },
  aboutCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  aboutIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  aboutLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
    fontFamily: 'Nunito_600SemiBold',
  },
  ownerName: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
    fontFamily: 'Nunito_700Bold',
    textAlign: 'center',
  },
  aboutDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 20,
    fontFamily: 'Nunito_400Regular',
  },
  versionText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 12,
    fontFamily: 'Nunito_400Regular',
  },
  resetButton: {
    backgroundColor: colors.secondary,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  resetButtonPressed: {
    opacity: 0.7,
  },
  resetButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    fontFamily: 'Nunito_700Bold',
  },
});

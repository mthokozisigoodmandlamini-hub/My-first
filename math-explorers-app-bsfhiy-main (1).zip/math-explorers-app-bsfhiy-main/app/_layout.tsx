
import React, { useEffect } from 'react';
import { useNetworkState } from 'expo-network';
import { useColorScheme, Alert } from 'react-native';
import { Stack, router } from 'expo-router';
import { SystemBars } from 'react-native-edge-to-edge';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import { WidgetProvider } from '@/contexts/WidgetContext';
import { ProgressProvider } from '@/contexts/ProgressContext';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import {
  DarkTheme,
  DefaultTheme,
  Theme,
  ThemeProvider,
} from '@react-navigation/native';
import * as SplashScreen from 'expo-splash-screen';
import { Button } from '@/components/button';
import { useFonts } from 'expo-font';
import {
  Nunito_400Regular,
  Nunito_600SemiBold,
  Nunito_700Bold,
  Nunito_800ExtraBold,
} from '@expo-google-fonts/nunito';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded] = useFonts({
    Nunito_400Regular,
    Nunito_600SemiBold,
    Nunito_700Bold,
    Nunito_800ExtraBold,
  });

  const colorScheme = useColorScheme();
  const { isConnected } = useNetworkState();

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  const customTheme: Theme = {
    ...DefaultTheme,
    colors: {
      ...DefaultTheme.colors,
      background: '#F7F2FA',
      card: '#FFFFFF',
      text: '#302C34',
      border: '#E9D5DA',
      primary: '#9A89B8',
      notification: '#F2BAC9',
    },
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ThemeProvider value={customTheme}>
        <WidgetProvider>
          <ProgressProvider>
            <SystemBars style="dark" />
            <StatusBar style="dark" />
            <Stack>
              <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
              <Stack.Screen
                name="modal"
                options={{
                  presentation: 'modal',
                  headerShown: false,
                }}
              />
              <Stack.Screen
                name="formsheet"
                options={{
                  presentation: 'formSheet',
                  headerShown: false,
                  sheetAllowedDetents: [0.5, 1],
                  sheetGrabberVisible: true,
                }}
              />
              <Stack.Screen
                name="transparent-modal"
                options={{
                  presentation: 'transparentModal',
                  animation: 'fade',
                  headerShown: false,
                }}
              />
              <Stack.Screen
                name="additionGame"
                options={{
                  presentation: 'card',
                  headerShown: true,
                }}
              />
              <Stack.Screen
                name="subtractionGame"
                options={{
                  presentation: 'card',
                  headerShown: true,
                }}
              />
              <Stack.Screen
                name="multiplicationGame"
                options={{
                  presentation: 'card',
                  headerShown: true,
                }}
              />
              <Stack.Screen
                name="divisionGame"
                options={{
                  presentation: 'card',
                  headerShown: true,
                }}
              />
            </Stack>
          </ProgressProvider>
        </WidgetProvider>
      </ThemeProvider>
    </GestureHandlerRootView>
  );
}


import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Pressable, Alert } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { colors } from '@/styles/commonStyles';
import { useProgress } from '@/contexts/ProgressContext';
import Animated, { FadeIn, FadeOut, ZoomIn, BounceIn } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';

export default function AdditionGame() {
  const router = useRouter();
  const { addScore } = useProgress();
  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [options, setOptions] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [feedback, setFeedback] = useState<string>('');

  useEffect(() => {
    generateQuestion();
  }, []);

  const generateQuestion = () => {
    const n1 = Math.floor(Math.random() * 20) + 1;
    const n2 = Math.floor(Math.random() * 20) + 1;
    const correctAnswer = n1 + n2;

    const wrongAnswers = [];
    while (wrongAnswers.length < 3) {
      const wrong = correctAnswer + Math.floor(Math.random() * 10) - 5;
      if (wrong !== correctAnswer && wrong > 0 && !wrongAnswers.includes(wrong)) {
        wrongAnswers.push(wrong);
      }
    }

    const allOptions = [correctAnswer, ...wrongAnswers].sort(() => Math.random() - 0.5);

    setNum1(n1);
    setNum2(n2);
    setOptions(allOptions);
    setFeedback('');
  };

  const handleAnswer = (answer: number) => {
    const correctAnswer = num1 + num2;
    
    if (answer === correctAnswer) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setFeedback('🎉 Correct!');
      const points = 10 + streak * 2;
      setScore(score + points);
      setStreak(streak + 1);
      addScore('addition', points);
      
      setTimeout(() => {
        generateQuestion();
      }, 1000);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setFeedback('❌ Try again!');
      setStreak(0);
      
      setTimeout(() => {
        setFeedback('');
      }, 1000);
    }
  };

  const handleQuit = () => {
    Alert.alert(
      'Quit Game?',
      `You scored ${score} points! Are you sure you want to quit?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Quit', style: 'destructive', onPress: () => router.back() },
      ]
    );
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Addition Game',
          headerStyle: {
            backgroundColor: colors.background,
          },
          headerTintColor: colors.text,
          headerTitleStyle: {
            fontFamily: 'Nunito_800ExtraBold',
          },
        }}
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.scoreContainer}>
            <Text style={styles.scoreLabel}>Score</Text>
            <Text style={styles.scoreValue}>{score}</Text>
          </View>
          <View style={styles.streakContainer}>
            <Text style={styles.streakLabel}>Streak</Text>
            <Text style={styles.streakValue}>{streak} 🔥</Text>
          </View>
        </View>

        <Animated.View entering={FadeIn} style={styles.questionContainer}>
          <Text style={styles.questionText}>
            {num1} + {num2} = ?
          </Text>
        </Animated.View>

        {feedback ? (
          <Animated.View entering={ZoomIn} exiting={FadeOut} style={styles.feedbackContainer}>
            <Text style={styles.feedbackText}>{feedback}</Text>
          </Animated.View>
        ) : null}

        <View style={styles.optionsContainer}>
          {options.map((option, index) => (
            <Animated.View
              key={`${option}-${index}`}
              entering={BounceIn.delay(index * 100)}
              style={styles.optionWrapper}
            >
              <Pressable
                style={({ pressed }) => [
                  styles.optionButton,
                  pressed && styles.optionButtonPressed,
                ]}
                onPress={() => handleAnswer(option)}
              >
                <Text style={styles.optionText}>{option}</Text>
              </Pressable>
            </Animated.View>
          ))}
        </View>

        <Pressable
          style={({ pressed }) => [
            styles.quitButton,
            pressed && styles.quitButtonPressed,
          ]}
          onPress={handleQuit}
        >
          <Text style={styles.quitButtonText}>Quit Game</Text>
        </Pressable>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 40,
  },
  scoreContainer: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    flex: 1,
    marginRight: 8,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  scoreLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 4,
    fontFamily: 'Nunito_600SemiBold',
  },
  scoreValue: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.primary,
    fontFamily: 'Nunito_800ExtraBold',
  },
  streakContainer: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    flex: 1,
    marginLeft: 8,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  streakLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 4,
    fontFamily: 'Nunito_600SemiBold',
  },
  streakValue: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.accent,
    fontFamily: 'Nunito_800ExtraBold',
  },
  questionContainer: {
    backgroundColor: colors.highlight,
    borderRadius: 24,
    padding: 40,
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 6px 16px rgba(162, 210, 255, 0.4)',
    elevation: 6,
  },
  questionText: {
    fontSize: 48,
    fontWeight: '800',
    color: colors.text,
    fontFamily: 'Nunito_800ExtraBold',
  },
  feedbackContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  feedbackText: {
    fontSize: 32,
    fontWeight: '800',
    fontFamily: 'Nunito_800ExtraBold',
  },
  optionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  optionWrapper: {
    width: '48%',
    marginBottom: 16,
  },
  optionButton: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
  },
  optionButtonPressed: {
    opacity: 0.7,
    transform: [{ scale: 0.95 }],
  },
  optionText: {
    fontSize: 36,
    fontWeight: '800',
    color: colors.text,
    fontFamily: 'Nunito_800ExtraBold',
  },
  quitButton: {
    backgroundColor: colors.secondary,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    marginTop: 'auto',
  },
  quitButtonPressed: {
    opacity: 0.7,
  },
  quitButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    fontFamily: 'Nunito_700Bold',
  },
});

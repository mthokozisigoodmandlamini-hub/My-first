
import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: string;
}

export interface GameProgress {
  addition: number;
  subtraction: number;
  multiplication: number;
  division: number;
}

interface ProgressContextType {
  badges: Badge[];
  gameProgress: GameProgress;
  totalScore: number;
  addScore: (game: keyof GameProgress, points: number) => void;
  earnBadge: (badgeId: string) => void;
  resetProgress: () => void;
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined);

const INITIAL_BADGES: Badge[] = [
  {
    id: 'first_steps',
    name: 'First Steps',
    description: 'Complete your first math problem!',
    icon: '🌟',
    earned: false,
  },
  {
    id: 'addition_master',
    name: 'Addition Master',
    description: 'Score 100 points in Addition',
    icon: '➕',
    earned: false,
  },
  {
    id: 'subtraction_star',
    name: 'Subtraction Star',
    description: 'Score 100 points in Subtraction',
    icon: '➖',
    earned: false,
  },
  {
    id: 'multiplication_hero',
    name: 'Multiplication Hero',
    description: 'Score 100 points in Multiplication',
    icon: '✖️',
    earned: false,
  },
  {
    id: 'division_champion',
    name: 'Division Champion',
    description: 'Score 100 points in Division',
    icon: '➗',
    earned: false,
  },
  {
    id: 'math_genius',
    name: 'Math Genius',
    description: 'Score 500 total points',
    icon: '🏆',
    earned: false,
  },
  {
    id: 'perfect_score',
    name: 'Perfect Score',
    description: 'Get 10 correct answers in a row',
    icon: '💯',
    earned: false,
  },
  {
    id: 'speed_demon',
    name: 'Speed Demon',
    description: 'Answer 5 questions in under 30 seconds',
    icon: '⚡',
    earned: false,
  },
];

export const ProgressProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [badges, setBadges] = useState<Badge[]>(INITIAL_BADGES);
  const [gameProgress, setGameProgress] = useState<GameProgress>({
    addition: 0,
    subtraction: 0,
    multiplication: 0,
    division: 0,
  });
  const [totalScore, setTotalScore] = useState(0);

  useEffect(() => {
    loadProgress();
  }, []);

  useEffect(() => {
    saveProgress();
  }, [badges, gameProgress, totalScore]);

  const loadProgress = async () => {
    try {
      const savedBadges = await AsyncStorage.getItem('badges');
      const savedProgress = await AsyncStorage.getItem('gameProgress');
      const savedScore = await AsyncStorage.getItem('totalScore');

      if (savedBadges) {
        setBadges(JSON.parse(savedBadges));
      }
      if (savedProgress) {
        setGameProgress(JSON.parse(savedProgress));
      }
      if (savedScore) {
        setTotalScore(JSON.parse(savedScore));
      }
    } catch (error) {
      console.log('Error loading progress:', error);
    }
  };

  const saveProgress = async () => {
    try {
      await AsyncStorage.setItem('badges', JSON.stringify(badges));
      await AsyncStorage.setItem('gameProgress', JSON.stringify(gameProgress));
      await AsyncStorage.setItem('totalScore', JSON.stringify(totalScore));
    } catch (error) {
      console.log('Error saving progress:', error);
    }
  };

  const addScore = (game: keyof GameProgress, points: number) => {
    setGameProgress((prev) => ({
      ...prev,
      [game]: prev[game] + points,
    }));
    setTotalScore((prev) => prev + points);

    // Check for badge achievements
    const newProgress = { ...gameProgress, [game]: gameProgress[game] + points };
    const newTotal = totalScore + points;

    // First Steps badge
    if (newTotal > 0 && !badges.find((b) => b.id === 'first_steps')?.earned) {
      earnBadge('first_steps');
    }

    // Game-specific badges
    if (newProgress.addition >= 100 && !badges.find((b) => b.id === 'addition_master')?.earned) {
      earnBadge('addition_master');
    }
    if (newProgress.subtraction >= 100 && !badges.find((b) => b.id === 'subtraction_star')?.earned) {
      earnBadge('subtraction_star');
    }
    if (newProgress.multiplication >= 100 && !badges.find((b) => b.id === 'multiplication_hero')?.earned) {
      earnBadge('multiplication_hero');
    }
    if (newProgress.division >= 100 && !badges.find((b) => b.id === 'division_champion')?.earned) {
      earnBadge('division_champion');
    }

    // Total score badge
    if (newTotal >= 500 && !badges.find((b) => b.id === 'math_genius')?.earned) {
      earnBadge('math_genius');
    }
  };

  const earnBadge = (badgeId: string) => {
    setBadges((prev) =>
      prev.map((badge) =>
        badge.id === badgeId
          ? { ...badge, earned: true, earnedDate: new Date().toISOString() }
          : badge
      )
    );
  };

  const resetProgress = async () => {
    setBadges(INITIAL_BADGES);
    setGameProgress({
      addition: 0,
      subtraction: 0,
      multiplication: 0,
      division: 0,
    });
    setTotalScore(0);
    await AsyncStorage.clear();
  };

  return (
    <ProgressContext.Provider
      value={{
        badges,
        gameProgress,
        totalScore,
        addScore,
        earnBadge,
        resetProgress,
      }}
    >
      {children}
    </ProgressContext.Provider>
  );
};

export const useProgress = () => {
  const context = useContext(ProgressContext);
  if (!context) {
    throw new Error('useProgress must be used within a ProgressProvider');
  }
  return context;
};

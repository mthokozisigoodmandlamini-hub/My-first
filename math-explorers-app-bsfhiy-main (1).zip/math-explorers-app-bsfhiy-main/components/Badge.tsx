
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '@/styles/commonStyles';
import Animated, { FadeIn, ZoomIn } from 'react-native-reanimated';

interface BadgeProps {
  icon: string;
  name: string;
  description: string;
  earned: boolean;
  earnedDate?: string;
}

export default function Badge({ icon, name, description, earned, earnedDate }: BadgeProps) {
  return (
    <Animated.View
      entering={earned ? ZoomIn.springify() : FadeIn}
      style={[styles.container, !earned && styles.locked]}
    >
      <View style={[styles.iconContainer, !earned && styles.lockedIcon]}>
        <Text style={styles.icon}>{earned ? icon : '🔒'}</Text>
      </View>
      <View style={styles.textContainer}>
        <Text style={[styles.name, !earned && styles.lockedText]}>{name}</Text>
        <Text style={[styles.description, !earned && styles.lockedText]}>
          {description}
        </Text>
        {earned && earnedDate && (
          <Text style={styles.date}>
            Earned: {new Date(earnedDate).toLocaleDateString()}
          </Text>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    marginVertical: 8,
    boxShadow: '0px 4px 12px rgba(154, 137, 184, 0.2)',
    elevation: 4,
    alignItems: 'center',
  },
  locked: {
    opacity: 0.5,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  lockedIcon: {
    backgroundColor: colors.secondary,
  },
  icon: {
    fontSize: 32,
  },
  textContainer: {
    flex: 1,
  },
  name: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
    fontFamily: 'Nunito_700Bold',
  },
  description: {
    fontSize: 14,
    color: colors.textSecondary,
    fontFamily: 'Nunito_600SemiBold',
  },
  lockedText: {
    color: colors.textSecondary,
  },
  date: {
    fontSize: 12,
    color: colors.primary,
    marginTop: 4,
    fontFamily: 'Nunito_600SemiBold',
  },
});
